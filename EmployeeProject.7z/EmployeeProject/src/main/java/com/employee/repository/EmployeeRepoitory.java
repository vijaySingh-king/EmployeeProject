package com.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employee.models.EmployeeDetails;

@Repository
public interface EmployeeRepoitory extends JpaRepository<EmployeeDetails, String> {

	boolean existsByEmail(String email);

	boolean existsByContactNumber(String contactNumber);

	EmployeeDetails findById(int id);
}
