package com.employee.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;

@Entity
public class EmployeeDetails {

	@TableGenerator(name = "detail_gen", initialValue = 10000, allocationSize = 100)
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "detail_gen")
	private int id;
	private String name = "";
	private String email = "";
	private String contactNumber = "";
	private String jobTitle = "";
	private String company = "";
	private String numberOfEmpoyees = "100-499";
	private String nameOfTheProcess = "";
	private String departmentFunction = "HR";
	private int resourcesInvolvedInTheProcess;
	private long minutesTakenByOneTransaction;
	private long totalTransactionsPerMonth;
	private String willingToShareTheSalaryToCalculateCostAvoidance = "NO";
	private double annualSalaryOfResource;
	private String currency = "INR";
	private int dataTypePercentOfStructuredData = 0;
	private int percentOfRuleBasedTransaction = 0;
	private int percentOfManualDecisionMaking = 0;
	private String needStandardisation = "NO";
	private String technicalCharacteristics = "NO";
	private int timeCriticality = 1;
	private int impactOfError = 1;

	private int qestion1 = 5;
	private int qestion2 = 5;
	private int qestion3 = 5;
	private int qestion4 = 5;
	private int qestion5 = 5;

	public EmployeeDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getNumberOfEmpoyees() {
		return numberOfEmpoyees;
	}

	public void setNumberOfEmpoyees(String numberOfEmpoyees) {
		this.numberOfEmpoyees = numberOfEmpoyees;
	}

	public String getNameOfTheProcess() {
		return nameOfTheProcess;
	}

	public void setNameOfTheProcess(String nameOfTheProcess) {
		this.nameOfTheProcess = nameOfTheProcess;
	}

	public String getDepartmentFunction() {
		return departmentFunction;
	}

	public void setDepartmentFunction(String departmentFunction) {
		this.departmentFunction = departmentFunction;
	}

	public int getResourcesInvolvedInTheProcess() {
		return resourcesInvolvedInTheProcess;
	}

	public void setResourcesInvolvedInTheProcess(int resourcesInvolvedInTheProcess) {
		this.resourcesInvolvedInTheProcess = resourcesInvolvedInTheProcess;
	}

	public long getMinutesTakenByOneTransaction() {
		return minutesTakenByOneTransaction;
	}

	public void setMinutesTakenByOneTransaction(long minutesTakenByOneTransaction) {
		this.minutesTakenByOneTransaction = minutesTakenByOneTransaction;
	}

	public long getTotalTransactionsPerMonth() {
		return totalTransactionsPerMonth;
	}

	public void setTotalTransactionsPerMonth(long totalTransactionsPerMonth) {
		this.totalTransactionsPerMonth = totalTransactionsPerMonth;
	}

	public String getWillingToShareTheSalaryToCalculateCostAvoidance() {
		return willingToShareTheSalaryToCalculateCostAvoidance;
	}

	public void setWillingToShareTheSalaryToCalculateCostAvoidance(String willingToShareTheSalaryToCalculateCostAvoidance) {
		this.willingToShareTheSalaryToCalculateCostAvoidance = willingToShareTheSalaryToCalculateCostAvoidance;
	}

	public double getAnnualSalaryOfResource() {
		return annualSalaryOfResource;
	}

	public void setAnnualSalaryOfResource(double annualSalaryOfResource) {
		this.annualSalaryOfResource = annualSalaryOfResource;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public int getDataTypePercentOfStructuredData() {
		return dataTypePercentOfStructuredData;
	}

	public void setDataTypePercentOfStructuredData(int dataTypePercentOfStructuredData) {
		this.dataTypePercentOfStructuredData = dataTypePercentOfStructuredData;
	}

	public int getPercentOfRuleBasedTransaction() {
		return percentOfRuleBasedTransaction;
	}

	public void setPercentOfRuleBasedTransaction(int percentOfRuleBasedTransaction) {
		this.percentOfRuleBasedTransaction = percentOfRuleBasedTransaction;
	}

	public int getPercentOfManualDecisionMaking() {
		return percentOfManualDecisionMaking;
	}

	public void setPercentOfManualDecisionMaking(int percentOfManualDecisionMaking) {
		this.percentOfManualDecisionMaking = percentOfManualDecisionMaking;
	}

	public String getNeedStandardisation() {
		return needStandardisation;
	}

	public void setNeedStandardisation(String needStandardisation) {
		this.needStandardisation = needStandardisation;
	}

	public String getTechnicalCharacteristics() {
		return technicalCharacteristics;
	}

	public void setTechnicalCharacteristics(String technicalCharacteristics) {
		this.technicalCharacteristics = technicalCharacteristics;
	}

	public int getTimeCriticality() {
		return timeCriticality;
	}

	public void setTimeCriticality(int timeCriticality) {
		this.timeCriticality = timeCriticality;
	}

	public int getImpactOfError() {
		return impactOfError;
	}

	public void setImpactOfError(int impactOfError) {
		this.impactOfError = impactOfError;
	}

	public int getQestion1() {
		return qestion1;
	}

	public void setQestion1(int qestion1) {
		this.qestion1 = qestion1;
	}

	public int getQestion2() {
		return qestion2;
	}

	public void setQestion2(int qestion2) {
		this.qestion2 = qestion2;
	}

	public int getQestion3() {
		return qestion3;
	}

	public void setQestion3(int qestion3) {
		this.qestion3 = qestion3;
	}

	public int getQestion4() {
		return qestion4;
	}

	public void setQestion4(int qestion4) {
		this.qestion4 = qestion4;
	}

	public int getQestion5() {
		return qestion5;
	}

	public void setQestion5(int qestion5) {
		this.qestion5 = qestion5;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [id=" + id + ", name=" + name + ", email=" + email + ", contactNumber=" + contactNumber
				+ ", jobTitle=" + jobTitle + ", company=" + company + ", numberOfEmpoyees=" + numberOfEmpoyees
				+ ", nameOfTheProcess=" + nameOfTheProcess + ", departmentFunction=" + departmentFunction
				+ ", resourcesInvolvedInTheProcess=" + resourcesInvolvedInTheProcess + ", minutesTakenByOneTransaction="
				+ minutesTakenByOneTransaction + ", totalTransactionsPerMonth=" + totalTransactionsPerMonth
				+ ", willingToShareTheSalaryToCalculateCostAvoidance=" + willingToShareTheSalaryToCalculateCostAvoidance
				+ ", annualSalaryOfResource=" + annualSalaryOfResource + ", currency=" + currency
				+ ", dataTypePercentOfStructuredData=" + dataTypePercentOfStructuredData
				+ ", percentOfRuleBasedTransaction=" + percentOfRuleBasedTransaction
				+ ", percentOfManualDecisionMaking=" + percentOfManualDecisionMaking + ", needStandardisation="
				+ needStandardisation + ", technicalCharacteristics=" + technicalCharacteristics + ", timeCriticality="
				+ timeCriticality + ", impactOfError=" + impactOfError + ", qestion1=" + qestion1 + ", qestion2="
				+ qestion2 + ", qestion3=" + qestion3 + ", qestion4=" + qestion4 + ", qestion5=" + qestion5 + "]";
	}

	
	
}
