package com.employee.service;

import java.util.LinkedHashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.employee.models.EmployeeDetails;
import com.employee.models.Result;
import com.employee.repository.EmployeeRepoitory;
import com.employee.util.Util;

/**
 * @author
 *
 */
@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepoitory employeeRepoitory;
	
	/**
	 * @param employee
	 * @return
	 */
	public ModelAndView calculateResult(EmployeeDetails employee) {

		System.out.println("empoyee data : "+employee);
		ModelAndView mv = new ModelAndView();
		
		Set<String> errors = new LinkedHashSet<String>();
		boolean status = this.validateEmployeeDetails(employee, errors);

		// errors check
		if (!status) {
			mv.addObject("employee", employee);
			mv.setViewName("index");
			mv.addObject("errors", errors);
			return mv;
		}
		
		
		// update  case
		if(employee.getId() != 0) {
			employeeRepoitory.save(employee);
			mv.addObject("result", this.calculateData(employee));
			mv.setViewName("result");
			mv.addObject("id",employee.getId());
			return mv;
		}
		

		EmployeeDetails save = employeeRepoitory.save(employee);

		mv.setViewName("result");
		mv.addObject("result", this.calculateData(employee));
		mv.addObject("id",save.getId());
		return mv;
	}

	private boolean validateEmployeeDetails(EmployeeDetails employee, Set<String> errors) {
		boolean isValid = true;

		if (Util.isNullOrBlank(employee.getName())) {
			isValid = false;
			errors.add("name is required");
		}
		if (Util.isNullOrBlank(employee.getEmail())) {
			isValid = false;
			errors.add("email is required");
		}
		if (Util.isNullOrBlank(employee.getContactNumber())) {
			isValid = false;
			errors.add("contact number is required");
		}
//		if(Util.isNullOrBlank(employee.getName())) {
//			isValid = false;
//			errors.add("");
//		}

		double manualEffort = (employee.getTotalTransactionsPerMonth()
				* (employee.getMinutesTakenByOneTransaction() * 12)) / 60;
		double fteHours = employee.getResourcesInvolvedInTheProcess() * 1920;
		if (manualEffort > fteHours) {
			isValid = false;
			errors.add("Manual hours cannot be greater than actual fte hours");
		}

		return isValid;
	}

	/**
	 * @param employee
	 * @return
	 */
	private Result calculateData(EmployeeDetails employee) {
		double extentOfAutomation = (double)employee.getDataTypePercentOfStructuredData()
				+ (double)employee.getPercentOfRuleBasedTransaction()
				+ 5 - (double)employee.getPercentOfRuleBasedTransaction()
				+ (double)(employee.getNeedStandardisation().trim().equals("YES") ? 0 : 5)
				+ (double)(employee.getTechnicalCharacteristics().trim().equals("YES") ? 0 : 5);

//		Effectiveness Score =
//				 ((Time Criticality )/5*100*0.33)+ ((Extent of Automation)/100*0.4* 0.33)+ [( 1-(impact of error)/5)*100*0.33)]

		int finalExtentOfAutomation = this.getExtentOfAutomationPercent(this.getScoreRating((int)extentOfAutomation).trim());
		
		double effectivenessScore = (((double)employee.getTimeCriticality() / 5.0) * 33.0)
				+ (((double)finalExtentOfAutomation/ 100.0) * 0.4 * 0.33)
				+ ((1.0 - ((double) employee.getImpactOfError() / 5.0)) * 33.0);
		
		System.out.println(effectivenessScore+" effectivenessScore"); 

		String effectivenessScoreRating =String.format("%.2f", effectivenessScore);
		
		
		

		double effortSaving = (12*employee.getTotalTransactionsPerMonth())
				* ((double)employee.getMinutesTakenByOneTransaction() / 60.0) * ((double)finalExtentOfAutomation / 100.0);

		double annualSaving = effortSaving * ((double)employee.getAnnualSalaryOfResource() / 1920.0);

		double fteSaving = ((effortSaving * 12) / 1920) / (double)employee.getResourcesInvolvedInTheProcess();

		int questionsSum=employee.getQestion1() + employee.getQestion2() + employee.getQestion3()+employee.getQestion4() + employee.getQestion5();
		System.out.println("questionsSum : "+questionsSum);
		double experienceScore = (1.0-((double)questionsSum/50.0))*100.0;

		System.out.println("experienceScore : "+experienceScore);
		
		Result result = new Result();

		System.out.println("effortsaving  :"+ effortSaving);
		
		result.setProcessName(employee.getNameOfTheProcess());
		result.setExtentOfAutomation(finalExtentOfAutomation+" %");
		String effScore = (this.calculateEfficiencyScore(employee, effortSaving)+"");
		result.setEfficiencyScore( effScore.split("\\.")[0]);
		result.setEffectivenessScore(effectivenessScoreRating+" %");
		result.setExperienceScore(String.valueOf(experienceScore)+"%");
		result.setEffortSavingHours(effortSaving);
		result.setAnnualSavings(Math.round(annualSaving));
		result.setCurrency(employee.getCurrency());
		result.setFteSavings(fteSaving);
		
		result.setEffortSavingsEquivalentToFte((effortSaving / 1920));
		

		System.out.println("result data : "+result);
		
		return result;
	}

	/**
	 * @param percent
	 * @return
	 */
	private int getvalueFromPercentString(String percent) {
		switch (percent) {
		case "0-15%":
			return 0;
		case "15-25%":
			return 1;
		case "25-50%":
			return 2;
		case "50-75%":
			return 3;
		case "75-90%":
			return 4;
		case "90-100%":
			return 5;
		default:
			return 0;
		}
	}

	/**
	 * @param number
	 * @return
	 */
	private String getScoreRating(int number) {

		switch (number) {
		case 1:
		case 2:
		case 3:
			return "0%";
		case 4:
		case 5:
		case 6:
			return "0-15%";
		case 7:
		case 8:
		case 9:
			return "15-25%";
		case 10:
		case 11:
		case 12:
			return "25-50%";
		case 13:
		case 14:
		case 15:
		case 16:
			return "50-75%";
		case 17:
		case 18:
		case 19:
		case 20:
			return "75-90%";
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
			return "90-100%";
		default:
			return "0%";
		}
	}

	/**
	 * @param details
	 * @return
	 */
	private double calculateEfficiencyScore(EmployeeDetails details, double effortSaving) {
//		double effortSavingScore = ((((double)details.getTotalTransactionsPerMonth()
//				* ((double)details.getMinutesTakenByOneTransaction() / 60.0)) * (extentOfAutomation / 100)) * 12) / 1920;
		
	double b =  	((double)this.getPremiumnessScore(details) / 5.0); 
	System.out.println("premiumnessscore "+b);
		double EfficiencyScore = ((     ((effortSaving / 5.0) * 0.6) +    (0.4 * (b / 5.0)))
				* 100.0);
		System.out.println("efficiency = "+EfficiencyScore);
		return EfficiencyScore;
	}

	/**
	 * Method to calculate premium ness score
	 * 
	 * @param details
	 * @return
	 */
	private int getPremiumnessScore(EmployeeDetails details) {

		double value = details.getAnnualSalaryOfResource();
		if (details.getCurrency().trim().equalsIgnoreCase("INR")) {

			if (Util.isValueIn(value, 0, 249600)) {
				return 1;
			}
			if (Util.isValueIn(value, 249600, 672000)) {
				return 2;
			}
			if (Util.isValueIn(value, 672000, 960000)) {
				return 3;
			}
			if (Util.isValueIn(value, 960000, 1497600)) {
				return 4;
			}
			if (Util.isValueIn(value, 1497600, Double.MAX_VALUE)) {
				return 5;
			}

		} else if (details.getCurrency().trim().equalsIgnoreCase("USD")) {
			if (Util.isValueIn(value, 0, 24960)) {
				return 1;
			}
			if (Util.isValueIn(value, 24960, 57600)) {
				return 2;
			}
			if (Util.isValueIn(value, 57600, 105600)) {
				return 3;
			}
			if (Util.isValueIn(value, 105600, 144000)) {
				return 4;
			}
			if (Util.isValueIn(value, 144000, Double.MAX_VALUE)) {
				return 5;
			}

		} else if (details.getCurrency().trim().equalsIgnoreCase("EURO")) {

			if (Util.isValueIn(value, 0, 19200)) {
				return 1;
			}
			if (Util.isValueIn(value, 19200, 34560)) {
				return 2;
			}
			if (Util.isValueIn(value, 34560, 53760)) {
				return 3;
			}
			if (Util.isValueIn(value, 53760, 76800)) {
				return 4;
			}
			if (Util.isValueIn(value, 76800, Double.MAX_VALUE)) {
				return 5;
			}

		} else if (details.getCurrency().trim().equalsIgnoreCase("GBP")) {

			if (Util.isValueIn(value, 0, 17280)) {
				return 1;
			}
			if (Util.isValueIn(value, 17280, 30720)) {
				return 2;
			}
			if (Util.isValueIn(value, 30720, 46080)) {
				return 3;
			}
			if (Util.isValueIn(value, 46080, 57600)) {
				return 4;
			}
			if (Util.isValueIn(value, 57600, Double.MAX_VALUE)) {
				return 5;
			}

		} else if (details.getCurrency().trim().equalsIgnoreCase("AUD")) {

			if (Util.isValueIn(value, 0, 48000)) {
				return 1;
			}
			if (Util.isValueIn(value, 48000, 76800)) {
				return 2;
			}
			if (Util.isValueIn(value, 76800, 115200)) {
				return 3;
			}
			if (Util.isValueIn(value, 115200, 153600)) {
				return 4;
			}
			if (Util.isValueIn(value, 153600, Double.MAX_VALUE)) {
				return 5;
			}
		}

		return 0;

	}

	/**
	 * @param id
	 * @return
	 */
	public ModelAndView editEmployeeDetails(int id) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		mv.addObject("employee", employeeRepoitory.findById(id));
		return mv;
	}
//	0%	0
//	0%	0
//	0%	0
//	0-15%	0
//	15-25%	20
//	25-50%	40
//	50-75%	60
//	75-90%	80
//	90-100%	95
	
	private int getExtentOfAutomationPercent(String percent) {
		switch (percent) {
		case "0%":
		case "0-15%":
			return 0;
		case "15-25%":
			return 20;
		case "25-50%":
			return 40;
		case "50-75%":
			return 60;
		case "75-90%":
			return 80;
		case "90-100%":
			return 95;
		default:
			return 0;
		}
	}


}
